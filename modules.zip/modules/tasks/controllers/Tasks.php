<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Tasks
 *
 * @author bk091
 */
class Tasks extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('m_tasks');
    }

    public function type() {
        $formData = array("page" => 0, "limit" => 10);
        $this->data['tasks_type_list'] = $this->m_tasks->getAllTaskType($formData);
        $formData['count'] = TRUE;
        $this->data['totalTaskTypes'] = $this->m_tasks->getAllTaskType($formData);
        $this->data['all_parent_task_types'] = $this->m_tasks->getAllTaskType(array("parent_id" => 0));
        $this->adminTemplate('tasks-type');
    }

    public function actions() {
        try {
            $formData = array();
            $formData = $this->input->post();
            if (empty($formData)) {

                throw new Exception("Invalid access !");
            }
            if (!isset($formData['action']) || (isset($formData['action']) && empty($formData['action']))) {
                throw new Exception("Action not define.");
            }
            $action = $formData['action'];

            if ($action == 'save_and_update_task_type') {
                if (!$this->m_tasks->save_and_update_task_type($formData)) {
                    throw new Exception("Error while processing.");
                }
                if (isset($formData['id']) && !empty($formData['id'])) {
                    $this->public_msg = "Update successfully.";
                } else {
                    $this->public_msg = "Save successfully.";
                }
                $this->response();
            } else if ($action == 'getAllTaskType') {
                $tasks_type_list = $this->m_tasks->getAllTaskType($formData);
                $formData['count'] = TRUE;
                $totalTaskTypes = $this->m_tasks->getAllTaskType($formData);
                $this->public_msg = "Task fetech successfully.";
                $this->response(array("list" => $tasks_type_list, "totalTaskTypes" => $totalTaskTypes));
            } else if ($action == 'deleteTaskType') {
                if (!$formData['id']) {
                    throw New Exception("Task Type id required.");
                }
                $child_task = $this->m_tasks->getAllTaskType(array('count' => TRUE, 'parent_id' => $formData['id']));
                if ($child_task) {
                    throw New Exception(" You can't delete because there are " . $child_task . " child thask type exist");
                }
                $this->load->model('project/m_project');
                $project_count = $this->m_project->getAllProject(array('count' => TRUE, 'task_types' => array($formData['id'])));
                if ($project_count) {
                    throw New Exception(" You can't delete because there are {$project_count} project are connected");
                }
                $id = $formData['id'];
                if (!$this->m_tasks->deleteTaskType($id)) {
                    throw New Exception("Error while deleting");
                }
                echo json_encode(array("succ" => true, "public_msg" => "Delete Successfull."));
            } else if ($action == 'editTaskType') {
                if (!$formData['id']) {
                    throw New Exception("Task Type id required.");
                }
                $id = $formData['id'];
                $editTaskType = $this->m_tasks->getAllTaskType(array('id' => $id));
                $this->public_msg = "Single Task fetech successfully.";
                $this->response(array("res" => $editTaskType));
            } else {

                $this->_err[] = "Invalid action define";
                throw new Exception();
            }
        } catch (Exception $ex) {
            $this->_err[] = $ex->getMessage();
            $this->response();
        }
    }

    public function get_parent_task_types() {
        $getparent_id = $this->m_tasks->getAllTaskType(array("parent_id" => 0));
        $this->public_msg = "Fetch parent task types successfully.";
        $this->response(array("res" => $getparent_id));
    }

}
