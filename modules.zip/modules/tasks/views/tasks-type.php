<style type="text/css">
    .p_info {
        background: #00BCD4;
    }

    .margin-t5x {
        margin-top: -5px;
    }
</style>
<div class="row" ng-controller="tasks">
    <div class="col-md-6" id="form_panal">
        <div class="card card-contrast">
            <div class="card-header card-header-contrast header-success">
                <div class="caption">
                    <button type="button" class="pull-left btn btn-danger"><i class="fa fa-{{Add}}"></i>&nbsp;{{text}} {{termType}}</button>
                </div>
            </div>
            <div class="card-body">
                <form role="form" id="task_type" ng-submit="add_task_type()">
                    <div class="form-body">
                        <input type="hidden" name="id" value="{{editdata.id}}" />
                        <input type="hidden" name="action" value="save_and_update_task_type">
                        <div class="form-group">
                            <label class="control-label">Task type</label>
                            <label class="control-label text-danger">(*)</label>
                            <input type="text" class="form-control" name="task_type" value="{{editdata.task_type_name}}" placeholder="Enter Task Type Name.">
                        </div>

                        <div class="form-group">
                            <label class="control-label">Parent Task</label>
                            <select class="form-control" name="parent_id" ng-model="editdata.parent_id">
                                <option value="0">--select--</option>
                                <option ng-repeat="eachTaskType in allParentTaskTypes" ng-if="editdata.id != eachTaskType.id" value="{{eachTaskType.id}}">{{eachTaskType.task_type_name}}</option>
                            </select>
                        </div>
                        <!--ng-if="editdata.id != eachTaskType.id"-->
                        <div class="form-group">
                            <label class="control-label">Status</label>
                            <label class="control-label text-danger">(*)</label>
                            <select class="form-control" name="status" ng-model="editdata.status">
                                <option value="">--select--</option>
                                <option value="1">Enable</option>
                                <option value="0">Disable</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-space btn-success"><i class="fa fa-{{Add}}"></i>&nbsp; {{text}} {{termType}} </button>
                                <button type="reset" ng-click="reset()" class="btn btn-space btn-danger"><i class="fa fa-times"> </i>&nbsp; Reset</button>
                            </div>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
    <div class="col-md-6" id="table_panel">
        <div class="card card-contrast">
            <div class="card-header header-primary">
                <div class="caption">
                    <button class="pull-right btn btn-success" ng-click="getAllTaskType()"><span class="fa fa-refresh"></span> <span class="hidden-sm">&nbsp; Refresh</span></button>
                </div>
            </div>
            <div class="card-body">
                <div class="table-scrollable">
                    <table class="table table-bordered table-hover table-responsive">
                        <thead>
                            <tr>
                                <th>S. No</th>
                                <th>Task Type</th>
                                <th>Parent</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <tr ng-repeat="eachTaskType in allTaskType">
                                <th>
                                    {{ $index + 1 }}
                                </th>
                                <td>
                                    {{eachTaskType.task_type_name}}
                                </td>
                                <td>
                                    <span ng-if="eachTaskType.task_type == null">NA</span>
                                    <span ng-if="eachTaskType.task_type != ''">{{eachTaskType.task_type}}</span>
                                </td>
                                <td>
                                    <span class="badge badge-success" ng-if="eachTaskType.status == 1">Enable</span>
                                    <span class="badge badge-danger" ng-if="eachTaskType.status == 0">Disable</span>
                                </td>
                                <td>
                                    <button class="btn btn-success" ng-click="editTaskType(eachTaskType.id)"><i class="fa fa-edit"></i>&nbsp; Edit</button>
                                    </br>
                                    <button class="btn btn-danger" ng-click="deleteTaskType(eachTaskType.id)"><i class="fa fa-trash"></i>&nbsp; Delete</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    app.controller('tasks', function($scope) {
        $scope.termType = "Task Type";
        $scope.text = "Add";
        $scope.page = '0';
        $scope.Add = 'plus';
        $scope.limit = '10';
        $scope.allTaskType = <?php echo json_encode($tasks_type_list); ?>;
        $scope.totalTasks = '<?php echo $totalTaskTypes; ?>';
        $scope.fromTasks = parseInt($scope.page) * parseInt($scope.limit);
        $scope.toTasks = parseInt($scope.fromTasks) + parseInt($scope.allTaskType.length);
        $scope.allParentTaskTypes = <?php echo json_encode($all_parent_task_types); ?>;
        $scope.editdata = {
            parent_id: '0'
        };

        $scope.reset = function() {
            $('#task_type')[0].reset();
            $scope.editdata = [];
            $scope.editdata = {
                parent_id: '0'
            };
            $scope.text = "Add";
            $scope.Add = "plus";
        };


        $scope.add_task_type = function() {
            $.ajax({
                url: "<?php echo base_url(); ?>tasks/tasks/actions",
                type: "post",
                dataType: 'json',
                data: $("#task_type").serialize(),
                success: function(data) {
                    if (data.succ) {
                        $scope.reset();
                        $scope.getAllTaskType();
                        $scope.getParentTaskTypes();
                    } else {
                        alert(data.public_msg);
                    }
                    $scope.$apply();
                }
            });
        };

        $scope.getAllTaskType = function() {
            $.ajax({
                url: "<?php echo base_url(); ?>tasks/tasks/actions",
                type: "post",
                data: {
                    action: 'getAllTaskType',
                    page: $scope.page,
                    limt: $scope.limit
                },
                dataType: "json",
                success: function(response) {
                    if (response.succ) {
                        $scope.allTaskType = response.data.list;
                        $scope.totalTasks = response.data.totalTaskTypes;
                        $scope.fromTasks = parseInt($scope.page) * parseInt($scope.limit);
                        $scope.toTasks = parseInt($scope.fromTasks) + parseInt($scope.allTaskType.length);
                    } else {
                        $scope.allTaskType = [];
                        $scope.totalTasks = '0';
                        $scope.fromTasks = '0';
                        $scope.toTasks = '0';
                    }
                    $scope.$apply();
                }
            });

        };

        $scope.deleteTaskType = function(id) {
            if (confirm('Are you sure want to delete this Tesk Type?')) {
                $.ajax({
                    url: "<?php echo base_url(); ?>tasks/tasks/actions",
                    type: "post",
                    data: {
                        action: 'deleteTaskType',
                        id: id
                    },
                    dataType: "json",
                    success: function(data) {
                        if (data.succ) {
                            $scope.getAllTaskType();
                        } else {
                            alert(data.public_msg);
                        }
                    }
                });
            }
        };

        $scope.editTaskType = function(id) {
            $.ajax({
                url: "<?php echo base_url(); ?>tasks/tasks/actions",
                type: "post",
                data: {
                    action: 'editTaskType',
                    id: id
                },
                dataType: "json",
                success: function(response) {
                    if (response.succ) {
                        $scope.text = "Update";
                        $scope.Add = "refresh";
                        $scope.editdata = response.data.res;
                    }
                    $scope.$apply();
                }
            });
        };
        $scope.getParentTaskTypes = function() {
            $.ajax({
                url: "<?php echo base_url(); ?>tasks/tasks/get_parent_task_types",
                type: "post",
                dataType: "json",
                success: function(response) {
                    if (response.succ) {
                        $scope.allParentTaskTypes = response.data.res;
                    }
                    $scope.$apply();
                }
            });
        };
    });
</script>