<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of M_tasks
 *
 * @author bk091
 */
Class M_tasks extends CI_Model {

    //put your code here

    public function save_and_update_task_type($formData) {
//        Validate Task Type Data
        $this->validateTaskType($formData);

        $insert_array = array(
            "task_type_name" => $formData['task_type'],
            "parent_id" => $formData['parent_id'],
            "status" => $formData['status']
        );

        if (isset($formData['id']) && !empty($formData['id'])) {
            return $this->db->update("task_types", $insert_array, array("id" => $formData['id']));
        } else {
            return $this->db->insert("task_types", $insert_array);
        }
    }

    public function validateTaskType($formData) {

        if (!isset($formData['task_type']) || (isset($formData['task_type']) && $formData['task_type'] == "")) {
            throw new Exception("Task type name is required.");
        } elseif (preg_match("/^[a-zA-Z ]*$/", $formData['task_type']) != 1) {
            throw new Exception("Only Alphabets Allow Task Type Name");
        } else if (strlen($formData['task_type']) > 30) {
            throw new Exception("Maximum 30 characters are allowed in task type name.");
        } else if ($this->getAllTaskType(array(
                    "task_type" => $formData['task_type'],
                    "not_id" => (isset($formData['id']) && $formData['id'] != '') ? $formData['id'] : '',
                    "count" => TRUE,
                ))) {
            throw new Exception($formData['task_type'] . " already exist.");
        }


        if (!isset($formData['status']) || (isset($formData['status']) && $formData['status'] == "")) {
            throw new Exception("Status is required.");
        }

        if (isset($formData['id']) && !empty($formData['id'])) {
            if (isset($formData['parent_id']) && !empty($formData['parent_id'])) {
                if ($formData['id'] == $formData['parent_id']) {
                    throw new Exception("You can't mark self parent.");
                }

                if ($this->getAllTaskType(array("count" => true, "parent_id" => $formData['id']))) {
                    throw new Exception("You can't update because there child is exist.");
                }
            }
        }
    }

    public function getAllTaskType($filters = array()) {
        $this->db->select('tt.* , ta.task_type_name as task_type');
        $this->db->from("task_types tt");
        $this->db->join('task_types ta', 'ta.id = tt.parent_id', "left");

        if (isset($filters['id']) && !empty($filters['id'])) {
            $this->db->where("tt.id", $filters['id']);
            return $this->db->get()->row_array();
        }
        if (isset($filters['task_type']) && $filters['task_type'] != '') {
            $this->db->where("tt.task_type_name", $filters['task_type']);
        }

        if (isset($filters['parent_id'])) {
            $this->db->where("tt.parent_id", $filters['parent_id']);
        }

        if (isset($filters['status'])) {
            $this->db->where("tt.status", $filters['status']);
        }

        if (isset($filters['not_id']) && $filters['not_id'] != '') {
            $this->db->where("tt.id !=", $filters['not_id']);
        }

        $this->db->group_by("tt.id");
        $this->db->order_by("tt.id", "DESC");

        if (isset($filters['count'])) {
            return $this->db->count_all_results();
        }

        $res =  $this->db->get()->result_array();

        if (!empty($res)) {
            foreach ($res as $index => $eachRes) {
                $filters['parent_id'] = $eachRes['id'];
                $res[$index]['child_TaskType'] = $this->getAllTaskType($filters);
            }
        }
        return $res;
    }

    public function deleteTaskType($id) {
        $this->db->where('id', $id);
        return $this->db->delete('task_types');
    }

    public function getparent_id() {
        $this->db->select("*")->from("task_types");
        $this->db->where('parent_id', '0');
        return $this->db->get()->result_array();
    }

}
