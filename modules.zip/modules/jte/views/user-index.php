<?php include('header.php');?>
  <!-- Navbar -->
<?php include('navbar.php');?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php include('sidebar.php');?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url()."assets/";?><?php echo base_url()."assets/";?>">Home</a></li>
              <li class="breadcrumb-item active">Dashboard v1</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->




<body ng-app="myApp">
<div class="row" ng-controller="project">
 



  <div class="col-md-6">


    <div class="card card-contrast">
      <div class="card-header card-header-contrast header-success">
        <div class="caption">
          <button type="button" class="pull-left btn btn-danger"><i class="fa fa-{{Add}}"></i>&nbsp;{{text}} {{project}}</button>
        </div>
      </div>
      <div class="card-body">
        <form role="form" id="project-form" ng-submit="save_or_update()">
          <div class="form-body">
            <input type="hidden" name="id" value="{{editdata.id}}" />
            <input type="hidden" name="action" value="save_or_update">

            <div class="form-group">
              <label class="control-label">Enter Name </label>
              <label class="control-label text-danger">(*)</label>
              <input type="text" placeholder="Enter Name" class="form-control" name="name" value="{{editdata.amount}}">
            </div>

           <div class="form-group">
              <label class="control-label">Enter Number </label>
              <label class="control-label text-danger">(*)</label>
              <input type="text" placeholder="Enter Number" class="form-control" name="number" value="{{editdata.amount}}">
            </div>
             
       <div class="form-group">
              <label class="control-label">Enter Email </label>
              <label class="control-label text-danger">(*)</label>
              <input type="text" placeholder="Enter Email" class="form-control" name="email" value="{{editdata.amount}}">
            </div>

            <div class="form-group">
              <label class="control-label">Enter Password </label>
              <label class="control-label text-danger">(*)</label>
              <input type="text" placeholder="Enter Password" class="form-control" name="password" value="{{editdata.amount}}">
            </div>

          <div class="form-group">
              <label class="control-label">Enter Age </label>
              <label class="control-label text-danger">(*)</label>
              <input type="text" placeholder="Enter Age" class="form-control" name="age" value="{{editdata.amount}}">
            </div>

             
       

          </div>

          <div class="form-group">
            <div class="row">
              <div class="col-md-12">
                <button type="submit" class="btn btn-space btn-success"><i class="fa fa-{{Add}}"></i>&nbsp; {{text}} {{project}} </button>
                <button type="reset" ng-click="reset()" class="btn btn-space btn-danger"><i class="fa fa-times"> </i>&nbsp; Reset</button>
              </div>
            </div>
          </div>

        </form>
      </div>
    </div>
  </div>
  <div class="col-md-6">
     
    <div class="card card-contrast">

       <div class="card-header header-primary">

        <button style="float:right;" class="btn btn-success pull-right" ng-disabled="toProjects == totalProjects" type="button" ng-click="nextList()"><i class="fa fa-step-forward"></i>Next</button> 
        
      <button style="float:right;" class="btn btn-danger pull-right " ng-disabled="page == 0" type="button" ng-click="preList()"><i class="fa fa-step-backward"></i>Pre</button>
          

       <select style="float:right;"  class="form-control col-sm-3" name="list" ng-change='getalluser();'   ng-model='limit'  >
               
               <option ng-repeat="eachlist in list" value="{{eachlist.id}}">{{eachlist.list_name}}</option> 
              </select>
      <span style="float:right;">{{fromProjects + 1}} - {{toProjects}} of {{totalProjects}}</span>

      </div>
    
           
             
          
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered table-hover">
            <thead>
              <tr>
                <th>S. No</th>
                <th>Name</th>
                <th>Number</th>
                <th>Email</th>
                <th>Password</th>
                <th>Age</th>
               
              </tr>
            </thead>

            <tbody>
              <tr ng-repeat="eachProject in allproject">
                <th>
                  {{ $index + 1+ fromProjects}}
                </th>
                <td>
                      {{eachProject.name}}
                  
                </td>
                <td>

                  {{eachProject.number}}
                </td>
                
                <td>
                  {{eachProject.email}}
                 
             
                </td>
                <td>
      
                     {{eachProject.password}}
                </td>
                  <td>
                  {{eachProject.age}}
                </td>
           
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
</body>

<script>
  $(function() {
    $('#project-form').bootstrapValidator({
      message: false,
      trigger: null,
      live: 'enabled',
      fields: {
        number: { // field name
          validators: {
            notEmpty: {
              message: 'Number  is required.'
            },
           
          }
        },
       
       

      }
    }).on('success.form.bv', function(e) {
      e.preventDefault();
    });
  });
</script>
 -->
<script>
  var app = angular.module('myApp', []);
  app.controller('project', function($scope,$filter) {
    $scope.project = "Project";
    $scope.text = "Add";
    $scope.Add = 'plus';
     $scope.totalProjects = '0';
    $scope.fromProjects = '0';
    $scope.toProjects = '0';
    $scope.limit = '5';
    console.log($scope.limit);
    $scope.page = '0';
     //$scope.editdata='0';



    $scope.reset = function() {
      $('#project-form')[0].reset();
      $('#project-form').bootstrapValidator('resetForm', true);
     
      $scope.editdata = [];
      $scope.text = "Add";
      $scope.Add = 'plus';
    }


$scope.list = <?php echo json_encode($list);?>;
console.log($scope.list);
$scope.preList = function(){
  $scope.page = parseInt($scope.page) - 1;
  window.setTimeout(function(){
    $scope.getallproject();
  },300);
}
$scope.nextList = function(){
  $scope.page = parseInt($scope.page) + 1;
  window.setTimeout(function(){
    $scope.getallproject();
  },300);
}



   

    $scope.getalluser = function() {
      $.ajax({
        url: "<?php echo base_url() ?>jte/user/actions",
        type: "post",
        data: {
          action: 'getalluser',page :$scope.page,limit:$scope.limit
        },
        dataType: "json",
        success: function(responce) {
          if (responce.succ) {
            $scope.allproject = responce.res;
             $scope.totalProjects = responce.total_projects;
            
    $scope.fromProjects = parseInt($scope.limit) * parseInt($scope.page);
    $scope.toProjects = parseInt($scope.fromProjects) + parseInt($scope.allproject.length);
          } else {

                  // $scope.allUsers = [];
                   $scope.totalProjects = '0';
                   $scope.fromProjects = '0';
                   $scope.toProjects = '0';
            alert(responce.public_msg);
            $scope.allproject = [];
          }
          $scope.$apply();
        }
      })
    }
    $scope.save_or_update = function() {
      // if (!$("#project-form").data('bootstrapValidator').validate().isValid()) {
       // return false;
      // }
      $.ajax({
        url: '<?php echo base_url() ?>jte/user/actions',
        'type': "post",
        data: $("#project-form").serialize(),
        dataType: 'json',
        success: function(response) {
          if (response) {
            $scope.reset();
          } else {
            alert(response.public_msg);
          }
        }

      });
    }
        angular.element(document).ready(function() {
      $scope.getalluser();

    });

    
  })
</script>



    <!-- Main content -->
   </div>
  <!-- /.content-wrapper -->
  <?php include('footer.php');?>