<?php
class M_user extends CI_Model
{
	

	public function save_or_update($formData)
	{
		
		$insert_array = array(
			"name  " => $formData['name'],
			"number" => $formData['number'],
			"email" => $formData['email'],
		    "password" => $formData['password'],
		    "age " => $formData['age']
		
		);

		if (isset($formData['id']) && !empty($formData['id'])) {

			return $this->db->update("user", $insert_array, array("id" => $formData['id']));
		} else {
			return $this->db->insert("user", $insert_array);
		}
	}

   
	public function getalluser($filters = array())
	{
		$this->db->select('s.*');
		$this->db->from('user s');
	
		if (isset($filters['id']) && !empty($filters['id'])) {
			$this->db->where("s.id", $filters['id']);
			return $this->db->get()->row_array();
		}
		$this->db->order_by('id', "DESC");
		$this->db->group_by('id');
		//$date=date("d-m-d");
	if(isset($filters['count'])){
		return $this->db->count_all_results();
	}
		if (isset($filters['limit']) && $filters['limit'] != 0) {
            $limit = $filters['limit'];
            $offset = (isset($filters['page']) && !empty($filters['page'])) ? $limit * $filters['page'] : 0;
            $this->db->limit($limit, $offset);
        }


		return $this->db->get()->result_array();
	}


public function checkNumberExists($filters = array())
{
		$this->db->select("id")->from("user");


if(isset($filters['not_id']) && !empty($filters['not_id'])){
	$this->db->where("id !=",$filters['not_id']);
}

if(isset($filters['number']) && !empty($filters['number'])){
	$this->db->where("number",$filters['number']);
}

		return $this->db->count_all_results();
	}


}
