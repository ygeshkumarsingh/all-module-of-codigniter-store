<?php
class User extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('m_user', 'ms');
	}
public function index()
	{
		 $this->data['list'] =array(
            array(
                "id" => '0',
                "list_name" => "All List"
            ),
            array(
                "id" => '5',
                "list_name" => "5 Per Page"
            ),array(
                "id" => '10',
                "list_name" => "10 Per Page"
            ),array(
                "id" => '50',
                "list_name" => "50 Per Page"
            ),array(
                "id" => '100',
                "list_name" => "100 Per Page"
            )

        );
     $this->load->view('user-index',$this->data);




      }



	public function actions()
	{
		try {
			$formData = $this->input->post();
			if (!isset($formData['action']) || (isset($formData['action']) && $formData['action'] == '')) {
				throw new Exception("Action not define");
			}
			$action = $formData['action'];
			if ($action == 'save_or_update') {
				$this-> _save_or_update($formData);
			} elseif ($action == 'getalluser') {
				$this->_getalluser($formData);
			} 
			else {
				throw new Exception("Invalid Action.");
			}
		} catch (Exception $ex) {
			echo json_encode(array("succ"=> false ,"public_msg" =>$ex->getMessage()));
		}
	}







public function _getalluser($formData)
	{
		//print_r($formData['limit']);
		//die();
		$getdata = $this->ms->getalluser($formData);
		$formData['count'] = TRUE;
		$this->public_msg = "Fetch  all user successfully.";
		$total_projects = $this->ms->getalluser($formData);
		echo json_encode(array("succ" => TRUE,"res" => $getdata,"total_projects"=>$total_projects));
	}
	public function _save_or_update($formData)
	{
		
		
		//$this->_validate_payable_amount_data($formData);
		if (!$update_approve=$this->ms->save_or_update($formData)) {
			throw new Exception("Error while processing.");
		}
		if (isset($formData['id']) && !empty($formData['id'])) {
			$this->public_msg = "Update successfully.";
		} else {
			$this->public_msg = "Save successfully.";
		}
		echo json_encode(array("res" => $update_approve));

	}

/* public function _otpmsg($formData)
   {
       $mobile = $formData['mobile'];
       $otp = $formData['otp'];
       $this->m_user->otp($formData);
       $username = 'trdemo';
       $password = 'demo1230';
       $sender = 'Brijesh';
       $message = 'One Time Password ';
       $url = "http://csms.advtworld.net/api/sendmessage.php?usr=" . $username . "&pwd=" . $password . "&sndr=" . $sender . "&ph=" . $mobile  . "&message=" . urlencode($message) . "" . $otp . "";
       $ch = curl_init();
       $timeout = 30;
       curl_setopt($ch, CURLOPT_URL, $url);
       curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
       curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
       $response = curl_exec($ch);
       curl_close($ch);
       //Write out the response
       return $response;
   }*/



public function _validate_project_user($formData)
	{
		if (!isset($formData['number']) || (isset($formData['number']) && $formData['number']) == '') {
			throw new Exception(" Number is required");
		}
		elseif (!preg_match("/[^0-9]/",$formData['number']) ){
			throw new Exception(" Number  Should Be in Correct Format");
		}
		elseif (strlen($formData['number']) >'10') {
			throw new Exception("Number length Can't Be More than 10 . ");
		}
		//print_r($formData['name']);
		//die();
		elseif ($this->ms->checkNumberExists(array(
			"number" => $formData['number'],
			"not_id"=> (isset($formData['id']) && !empty($formData['id'])) ? $formData['id'] : ''
		))) {
		
		//alert("Name is exists");
              	  throw new Exception("Number is exists");
                 	
            }  


	
	}













/*

class User extends MX_Controller  {

public function __construct(){

        parent::__construct();
        $this->load->helper('url');
        $this->load->model('user_model');
        $this->load->library('session');



public function index()
{
$this->load->view("register.php");
}

public function register_user(){

      $user=array(
      'user_name'=>$this->input->post('user_name'),
      'user_email'=>$this->input->post('user_email'),
      'user_password'=>md5($this->input->post('user_password')),
      'user_age'=>$this->input->post('user_age'),
      'user_mobile'=>$this->input->post('user_mobile')
        );
        print_r($user);

$email_check=$this->user_model->email_check($user['user_email']);

if($email_check){
  $this->user_model->register_user($user);
  $this->session->set_flashdata('success_msg', 'Registered successfully.Now login to your account.');
  redirect('login/user/login_view');

}
else{

  $this->session->set_flashdata('error_msg', 'Error occured,Try again.');
  redirect('login/user');


}

}

public function login_view(){

$this->load->view("login.php");

}

function login_user(){ 
 

  $user_email=$this->input->post('user_email');
  $user_password=md5($this->input->post('user_password'));

   
//$user_login['user_email'],$user_login['user_password']
    $data['users']=$this->user_model->login_user($user_email,$user_password);
   // print_r($data);
   //die();
     if(!empty($data['users']))
     {
        
          $this->session->set_userdata('user_id',$data['users'][0]['user_id']);
        $this->session->set_userdata('user_email',$data['users'][0]['user_email']);
        $this->session->set_userdata('user_name',$data['users'][0]['user_name']);
        $this->session->set_userdata('user_age',$data['users'][0]['user_age']);
      $this->session->set_userdata('user_mobile',$data['users'][0]['user_mobile']);
    echo $this->session->set_userdata('user_id'); 
        $this->load->view('user_profile.php',$data);

      }
   else{
       $this->session->set_flashdata('error_msg', 'Error occured,Try again.');
       $this->load->view("login.php");

     }


}

function user_profile(){

$this->load->view('user_profile.php');

}
public function user_logout(){

  $this->session->sess_destroy();
  redirect('login/user/login_view', 'refresh');
}




}

