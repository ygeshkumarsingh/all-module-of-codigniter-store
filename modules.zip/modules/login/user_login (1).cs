using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
namespace Store
{
    #region User_login
    public class User_login
    {
        #region Member Variables
        protected int _user_id;
        protected string _user_name;
        protected string _user_email;
        protected string _user_password;
        protected int _user_age;
        protected int _user_mobile;
        #endregion
        #region Constructors
        public User_login() { }
        public User_login(int user_id, string user_name, string user_email, string user_password, int user_age, int user_mobile)
        {
            this._user_id=user_id;
            this._user_name=user_name;
            this._user_email=user_email;
            this._user_password=user_password;
            this._user_age=user_age;
            this._user_mobile=user_mobile;
        }
        #endregion
        #region Public Properties
        public virtual int User_id
        {
            get {return _user_id;}
            set {_user_id=value;}
        }
        public virtual string User_name
        {
            get {return _user_name;}
            set {_user_name=value;}
        }
        public virtual string User_email
        {
            get {return _user_email;}
            set {_user_email=value;}
        }
        public virtual string User_password
        {
            get {return _user_password;}
            set {_user_password=value;}
        }
        public virtual int User_age
        {
            get {return _user_age;}
            set {_user_age=value;}
        }
        public virtual int User_mobile
        {
            get {return _user_mobile;}
            set {_user_mobile=value;}
        }
        #endregion
    }
    #endregion
}