<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Store_manager extends MY_Controller 
{
	public function __construct()
	{
	//call CodeIgniter's default Constructor
	parent::__construct();
  $this->load->library('form_validation');
	
	$this->load->helper('url');
	 $this->load->helper('form');
	//load database libray manually
	 //echo 	base_url("store_manager/dispdata");
	$this->load->database();
	
	//load Model
	$this->load->model('m_store_manager');
	}
     
	public function fetch_term()
	{
 
                
                $this->form_validation->set_rules('store_name', 'Store Name', 'required');
                $this->form_validation->set_rules('contact', 'Mobile Number','required|regex_match[/^[0-9]{10}$/]');
                $this->form_validation->set_rules('latitude', 'Latitude', 'required');
               $this->form_validation->set_rules('longitude', 'longitude', 'required'); 
                $this->form_validation->set_rules('state', 'state', 'required');
                $this->form_validation->set_rules('city', 'city', 'required');
                  $this->form_validation->set_rules('status', 'status', 'required');

try {
    // run your code here


          if ($this->form_validation->run() == FALSE)
                {
                 
                $this->index();
               // $this->load->view('store_manager_index');
                }
                else
                {
                        
                


		$postData = $this->input->post();
		$this->load->view('store_manager_index');
	//	if(!empty($postData)){
        //print_r($postData);
if(isset($postData)){
   
       $store_name=$this->input->post('store_name');

		$contact=$this->input->post('contact');
		$latitude=$this->input->post('latitude');
        $longitude=$this->input->post('longitude');
		$state=$this->input->post('state');
		$city=$this->input->post('city');
		$status=$this->input->post('status');
       
	
    $this->m_store_manager->saverecords($store_name,$contact,$latitude,$longitude,$state,$city,$status);	

    redirect(base_url("store_manager/dispdata"));  	
		//echo "Records Saved Successfully";
		//load registration view form
		
	
		//Check submit button 
    }

 	}

 	}
catch (Exception $e) {
    echo $e->getMessage();
}

	
}
public function index()
	{
	$result['data']=$this->m_store_manager->fetch_term();
    $result['city']=$this->m_store_manager->fetch_term1();
    //$formdata = $this->input->post();
    // if(isset($formdata['save']))
         
	$this->load->view('store_manager_index',$result);
	//$this->load->view('store_manager_index',$result);
	}


public function dispdata()
	{
	$result['data']=$this->m_store_manager->displayrecords();
	$this->load->view('display_records',$result);
	}
	public function deletedata()
	{
	$id=$this->input->get('id');
	$this->m_store_manager->deleterecords($id);
	redirect("store_manager/dispdata");
	}

	public function updatedata()
	{
		$result['state']=$this->m_store_manager->fetch_term();
    $result['city']=$this->m_store_manager->fetch_term1();
	$id=$this->input->get('id');
	$result['data']=$this->m_store_manager->displayrecordsById($id);
	$this->load->view('update_records',$result);	
	
		if($this->input->post('update'))
		{
		
		$store_name=$this->input->post('store_name');
		$contact=$this->input->post('contact');
        $latitude=$this->input->post('latitude');
        $longitude=$this->input->post('longitude');
	    $state=$this->input->post('state');
		$city=$this->input->post('city');
		$status=$this->input->post('status');
		$this->m_store_manager->updaterecords($store_name,$contact,$latitude,$longitude,$state,$city,$status,$id);
				redirect("store_manager/dispdata");
		}
	}

    public function term_type()
	{
	$parent_id=$this->input->post('parent_id');
	$term_type=$this->input->post('term_type');
		if(!empty($parent_id)){
       // print_r($parent_id);
        	//$this->load->view('store_manager_index',$parent_id);
       $res= $this->m_store_manager->fetch_city($parent_id,$term_type);
        echo json_encode(array("city" => $res));
    }
	
	
	}



	
}
?>