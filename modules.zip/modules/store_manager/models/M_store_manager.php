<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class M_store_manager extends CI_Model 
{

	public function __construct()
	{
	//call CodeIgniter's default Constructor
	parent::__construct();

	}

	function saverecords($store_name,$contact,$latitude,$longitude,$state,$city,$status)
	{

	$query="insert into Store values('','$store_name','$contact','$latitude','$longitude','$state','$city','$status')";
	$this->db->query($query);
	}

	function displayrecords()
	{
	$query=$this->db->query("select * from Store");
	return $query->result();
	}
	function deleterecords($id)
	{
	$this->db->query("delete  from Store where id='".$id."'");
	}

	function displayrecordsById($id)
	{
	$query=$this->db->query("select * from Store where id='".$id."'");
	return $query->result();
	}
	
	function updaterecords($store_name,$contact,$latitude,$longitude,$state,$city,$status,$id)
	{
	$query=$this->db->query("update Store SET StoreName='$store_name',Contact='$contact',latitude='$latitude',longitude='$longitude',state='$state',city='$city',status='$status' where id='".$id."'");
		//echo $this->db->last_query();
		//die();
	}

		function fetch_term()
	{
	//$query=$this->db->query("select state from Store");
	//return $query->result();
		$this->db->select('id,name');
		$this->db->from('arc_terms');
		$this->db->where('term_type',"states");
		//return  $this->db->get()->row();
		//retrun $this->db->get()->result_array();
		return $this->db->get()->result_array();
	}	

		function fetch_term1()
	{
	//$query=$this->db->query("select state from Store");
	//return $query->result();
		$this->db->select('id,name,parent_id');
		$this->db->from('arc_terms');
		$this->db->where('term_type',"city");
		//return  $this->db->get()->row();
		//retrun $this->db->get()->result_array();
		return $this->db->get()->result_array();
	}	

	function fetch_city($parent_id,$term_type)
	{
	 $response = array();
       $this->db->select('*');
      $this->db->where('parent_id', $parent_id);
        $this->db->where('term_type', $term_type);
      $q = $this->db->get('arc_terms');
      $response = $q->result_array();
      return $response;	
	}	
	
}
 


 