<!DOCTYPE html>
<html>
    <head>
        <title>CodeIgniter  Email Send using SMTP</title>
    </head>
    <body>
        <div>
            <h3>Use the form below to send email</h3>
            <form method="post" action="<?php echo base_url();?>email_test/emailcontroller/send"  >
                <input type="email" name="to" placeholder="Enter Receiver Email">
                <br><br>
                <input type="text" name="subject" placeholder="Enter Subject">
                <br><br>
                <textarea rows="6" name="message" placeholder="Enter your message here"></textarea>
                <br><br>
                <input type="submit" value="Send Email" />
            </form>
        </div>
    </body>
</html>