<?php
class Projects extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('m_projects', 'ms');
	}

	public function payable_amount()
	{
		//
		$this->data['projects'] =array(
            array(
                "id" => '1',
                "project_name" => "NexGen Innovators"
            ),array(
                "id" => '2',
                "project_name" => "Project Tracker"
            ),array(
                "id" => '3',
                "project_name" => "Navtech"
            )
        );
        $this->data['list'] =array(
            array(
                "id" => '0',
                "list_name" => "All List"
            ),
            array(
                "id" => '5',
                "list_name" => "5 Per Page"
            ),array(
                "id" => '10',
                "list_name" => "10 Per Page"
            ),array(
                "id" => '50',
                "list_name" => "50 Per Page"
            ),array(
                "id" => '100',
                "list_name" => "100 Per Page"
            )

        );
		 $this->load->view('projects-payable-amount',$this->data);
	}

	
     public function type()
    {
    	//print_r("hfhgf");
    	//die();
    	 $this->data['list'] =array(
            array(
                "id" => '0',
                "list_name" => "All List"
            ),
            array(
                "id" => '5',
                "list_name" => "5 Per Page"
            ),array(
                "id" => '10',
                "list_name" => "10 Per Page"
            ),array(
                "id" => '50',
                "list_name" => "50 Per Page"
            ),array(
                "id" => '100',
                "list_name" => "100 Per Page"
            )

        );
     $this->load->view('projects-type',$this->data);
      }

	public function actions()
	{
		try {
			$formData = $this->input->post();
			if (!isset($formData['action']) || (isset($formData['action']) && $formData['action'] == '')) {
				throw new Exception("Action not define");
			}
			$action = $formData['action'];
			if ($action == 'save_or_update_payable_amount') {
				$this-> _save_or_update_payable_amount($formData);
			} elseif ($action == 'get_payable_amount') {
				$this->_get_payable_amount($formData);
			} elseif ($action == 'delete_payable_amount') {
				$this->_delete_payable_amount($formData);
			} elseif ($action == 'edit_payable_amount') {
				$this->_edit_payable_amount($formData);
			} elseif ($action == 'save_or_update_project_type') {
				$this->_save_or_update_project_type($formData);
			} elseif ($action == 'get_project_type') {
				$this->_get_project_type($formData);
			}
			elseif ($action == 'delete_project_type') {
				$this->_delete_project_type($formData);
			}
			elseif ($action == 'edit_project_type') {
				$this->_edit_project_type($formData);
			}
			else {
				throw new Exception("Invalid Action.");
			}
		} catch (Exception $ex) {
			echo json_encode(array("succ"=> false ,"public_msg" =>$ex->getMessage()));
		}
	}

	public function _edit_payable_amount($formData)
	{
		if (!$formData['id']) {
			throw new Exception("Cap Id is required.");
		}
		$edit_project = $this->ms->get_payable_amount(array("id" => $formData['id']));
		$this->public_msg = "Single cap fetch successfully .";
		echo json_encode(array("res" => $edit_project));
	}

public function _edit_project_type($formData)
	{
		if (!$formData['id']) {
			throw new Exception("Cap Id is required.");
		}
		$edit_project_type = $this->ms->get_project_type(array("id" => $formData['id']));
		$this->public_msg = "Single cap fetch successfully .";
		echo json_encode(array("res" => $edit_project_type));
	}

	public function _delete_payable_amount($formData)
	{
		if (!$formData['id']) {
			throw new Exception("Project id is required");
		}
		$deletproject = $this->ms->delete_payable_amount(array("id" => $formData['id']));
		$this->public_msg = "Caps Deleted successfully .";
		echo json_encode(array("res" => $deletproject ,"msg"=>$this->public_msg));
	}


	public function _delete_project_type($formData)
	{
		if (!$formData['id']) {
			throw new Exception("Project id is required");
		}
		$deletproject = $this->ms->delete_project_type(array("id" => $formData['id']));
		$this->public_msg = " Deleted successfully .";
		echo json_encode(array("res" => $deletproject,"msg"=>$this->public_msg));
	}
	public function _get_project_type($formData)
	{
		//print_r($formData['limit']);
		//die();
		$getdata = $this->ms->get_project_type($formData);
		$formData['count'] = TRUE;
		$this->public_msg = "Fetch  all Payable successfully.";
		$total_projectstype = $this->ms->get_project_type($formData);
		echo json_encode(array("succ" => TRUE,"res" => $getdata,"total_projectstype"=>$total_projectstype));
	}

public function _get_payable_amount($formData)
	{
		//print_r($formData['limit']);
		//die();
		$getdata = $this->ms->get_payable_amount($formData);
		$formData['count'] = TRUE;
		$this->public_msg = "Fetch  all Payable successfully.";
		$total_projects = $this->ms->get_payable_amount($formData);
		echo json_encode(array("succ" => TRUE,"res" => $getdata,"total_projects"=>$total_projects));
	}
	public function _save_or_update_payable_amount($formData)
	{
		
		if(!isset($formData['will_repeat']))
		{
			$formData['will_repeat']='0';
		}
		else
		{
			$formData['will_repeat']='1';
		}
		//print_r($formData['will_repeat']);
		//die();
		$this->_validate_payable_amount_data($formData);
		if (!$update_approve=$this->ms->save_or_update_payable_amount($formData)) {
			throw new Exception("Error while processing.");
		}
		if (isset($formData['id']) && !empty($formData['id'])) {
			$this->public_msg = "Update successfully.";
		} else {
			$this->public_msg = "Save successfully.";
		}
		echo json_encode(array("res" => $update_approve,"msg"=>$this->public_msg));
	}

public function _save_or_update_project_type($formData)
	{
		
	
		//print_r($formData['will_repeat']);
		//die();
		$this->_validate_project_type_data($formData);
		if (!$update_approve=$this->ms->save_or_update_project_type($formData)) {
			throw new Exception("Error while processing.");
		}
		if (isset($formData['id']) && !empty($formData['id'])) {
			$this->public_msg = "Update successfully.";
		} else {
			$this->public_msg = "Save successfully.";
		}
		echo json_encode(array("res" => $update_approve));
	}


public function _validate_project_type_data($formData)
	{
		if (!isset($formData['name']) || (isset($formData['name']) && $formData['name']) == '') {
			throw new Exception(" Name is required");
		}
		if (!preg_match("/^[-_ a-zA-Z0-9]+$/",$formData['name']) ){
			throw new Exception(" Name  Should Be in Correct Format");
		}
		if (strlen($formData['name']) >'30') {
			throw new Exception("Name length Can't Be More than 30 . ");
		}
		//print_r($formData['name']);
		//die();
		if ($this->ms->checkProjectTypeExists(array(
			"name" => $formData['name'],
			"not_id"=> (isset($formData['id']) && !empty($formData['id'])) ? $formData['id'] : ''
		))) {
		
		//alert("Name is exists");
              	  throw new Exception("Name is exists");
                 	
            }  


		if (!isset($formData['code']) || (isset($formData['code']) && $formData['code']) == '') {
			throw new Exception("Code is required");
		}
		if (!preg_match("/^[-_ a-zA-Z0-9]+$/",$formData['code']) ){
			throw new Exception(" Code  Should Be in Correct Format");
		}
		if ($this->ms->checkProjectTypeExists(array(
			"code" => $formData['code'],
			"not_id"=> (isset($formData['id']) && !empty($formData['id'])) ? $formData['id'] : ''
		))) {
		
              	  throw new Exception("Code is exists");
                 	
            } 
		if (!is_numeric($formData['code'])) {
			throw new Exception("Code must be numeric. ");
		}
		 if (strlen($formData['code']) >'7' ) {
			throw new Exception("Code must be 7 digits. ");
		}
		if (!isset($formData['hsn_code']) || (isset($formData['hsn_code']) && $formData['hsn_code']) == '') {
			throw new Exception("HSN Code is required");
		}
			if (strlen($formData['discription']) >'150') {
			throw new Exception("Discription  Sholud be Less Then 150 Charecter");
		}
	//	print_r($formData['status']);
	//	die();
		// if (!isset($formData['status']) || (isset($formData['status']) && $formData['status']) == '') {
		// 	throw new Exception("Status is required");
		// } 
	
	}




	public function _validate_payable_amount_data($formData)
	{
		if (!isset($formData['project']) || (isset($formData['project']) && $formData['project']) == '') {
			throw new Exception(" Project name is required");
		} 
		if (!isset($formData['amount']) || (isset($formData['amount']) && $formData['amount']) == '') {
			throw new Exception("Amount is required");
		} 
		else if (!is_numeric($formData['amount'])) {
			throw new Exception("Amount must be 10 digits. and ");
		}
		 else if (strlen($formData['amount']) >'1' && strlen($formData['amount'] <'7')) {
			throw new Exception("Amount must be 10 digits. ");
		}
		
		if (!isset($formData['due_date']) || (isset($formData['due_date']) && $formData['due_date']) == '') {
			throw new Exception("Due Date is required");
		} 
		if (strlen($formData['remarks']) >'150') {
			throw new Exception("Remarks  Sholud be Less Then 150 Charecter");
		} 
	}
}

