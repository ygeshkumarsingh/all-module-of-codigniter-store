<?php include('header.php')?>
  <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.2/css/bootstrapValidator.min.css"/>
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.2/js/bootstrapValidator.min.js"></script>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link href="https://use.fontawesome.com/releases/v5.0.4/css/all.css" rel="stylesheet">

<body ng-app="myApp">
<div class="row" ng-controller="project">
 



  <div class="col-md-6">


    <div class="card card-contrast">
      <div class="card-header card-header-contrast header-success">
        <div class="caption">
          <button type="button" class="pull-left btn btn-danger"><i class="fa fa-{{Add}}"></i>&nbsp;{{text}} {{project}}</button>
        </div>
      </div>
      <div class="card-body">
        <form role="form" id="project-type-form" ng-submit="save_or_update_project_type()">
          <div class="form-body">
            <input type="hidden" name="id" value="{{editdata.id}}" />
            <input type="hidden" name="action" value="save_or_update_project_type">

    


            <div class="form-group">
              <label class="control-label">Enter Name  </label>
              <label class="control-label text-danger">(*)</label>
              <input type="text" placeholder="Enter Name" class="form-control" name="name" value="{{editdata.name}}">
            </div>

           
           <div class="form-group">
              <label class="control-label">Enter Code  </label>
              <label class="control-label text-danger">(*)</label>
              <input type="text" placeholder="Enter Code" class="form-control" name="code" value="{{editdata.code}}">
            </div>

            <div class="form-group">
              <label class="control-label">Status</label>
              <label class="control-label text-danger">(*)</label>
              <select class="form-control" name="status" ng-model="editdata.status">
                <option value="">--select--</option>
                <option value="1">Enable</option>
                <option value="0">Disable</option>
              </select>
            </div>
         

           <div class="form-group">
              <label class="control-label">Enter HSN Code  </label>
              <label class="control-label text-danger">(*)</label>
              <input type="text" placeholder="Enter HSN Code" class="form-control" name="hsn_code" value="{{editdata.hsn_code}}">
            </div>

            <div class="form-group">
              <label class="control-label">Enter Discription </label>
          
              <textarea name="discription" class="form-control"  
              
               placeholder="Enter  Discription"> {{editdata.discription}}</textarea> 
          
            </div>
          </div>

          <div class="form-group">
            <div class="row">
              <div class="col-md-12">
                <button type="submit" class="btn btn-space btn-success"><i class="fa fa-{{Add}}"></i>&nbsp; {{text}} {{project}} </button>
                <button type="reset" ng-click="reset()" class="btn btn-space btn-danger"><i class="fa fa-times"> </i>&nbsp; Reset</button>
              </div>
            </div>
          </div>

        </form>
      </div>
    </div>
  </div>
  <div class="col-md-6">
     
    <div class="card card-contrast">

       <div class="card-header header-primary">

        <button style="float:right;" class="btn btn-success pull-right" ng-disabled="toProjectstype == totalProjectstype" type="button" ng-click="nextList()"><i class="fa fa-step-forward"></i>Next</button> 
        
      <button style="float:right;" class="btn btn-danger pull-right " ng-disabled="page == 0" type="button" ng-click="preList()"><i class="fa fa-step-backward"></i>Pre</button>
          

       <select style="float:right;"  class="form-control col-sm-3" name="list" ng-change='getallprojectType();'   ng-model='limit'  >
               
               <option ng-repeat="eachlist in list" value="{{eachlist.id}}">{{eachlist.list_name}}</option> 
              </select>
      <span style="float:right;">{{fromProjectstype + 1}} - {{toProjectstype}} of {{totalProjectstype}}</span>

      </div>
    
           
             
          
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered table-hover">
            <thead>
              <tr>
                <th>S. No</th>
                <th>Name</th>
                <th>Code</th>
                <th>Status</th>
                <th>HSN Code</th>
                <th>Discription</th>
                <th>Action</th>
              </tr>
            </thead>

            <tbody>
              <tr ng-repeat="eachProjecttype in allprojecttype">
                <th>
                  {{ $index + 1+ fromProjectstype}}
                </th>
                <td>
               {{eachProjecttype.name}}
                </td>
                <td>

                  {{eachProjecttype.code}}
                </td>
                
                <td>
                 
                 
                <span class="badge badge-success" ng-if="eachProjecttype.status == 1">Enable</span>
                  <span class="badge badge-danger" ng-if="eachProjecttype.status == 0">Disable</span> 
                </td>
                 <td>

                  {{eachProjecttype.hsn_code}}
                </td>
                 <td>

                  {{eachProjecttype.discription}}
                </td>
              
                <td>
                  <button class="btn btn-success" ng-click="editProjectType(eachProjecttype.id)"><i class="fa fa-edit"></i>Edit</button>
                  <button class="btn btn-danger" ng-click="deleteProjectType(eachProjecttype.id)"><i class="fa fa-trash"></i> Delete</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
<script>
        $('#datepicker').datepicker({
            uiLibrary: 'bootstrap4'
        });
    </script>
<script>
  $(function() {
    $('#project-type-form').bootstrapValidator({
      message: false,
      trigger: null,
      live: 'enabled',
      fields: {
        name: { // field name
          validators: {
            notEmpty: {
              message: 'Name  is required.'
            },
            regexp: {
              regexp: /^[-_ a-zA-Z0-9]+$/,
              message: 'A-z,space and - are allowed in  Name.'
            },
             stringLength: {
              max: 30,
              min: 2,
              message: 'Only 30 characters are Name.'
            }
          }
        },

        code: { // field name
          validators: {
            notEmpty: {
              message: 'Code  is required.'
            },
             regexp: {
              regexp: /^[-_ a-zA-Z0-9]+$/,
              message: 'A-z,space and - are allowed in  Code.'
            },
            
            stringLength: {
              max: 10,
              min: 1,
              message: 'Only 10 characters are Code.'
            }
          }
        },
        hsn_code:{ // field name
          validators: {
            notEmpty: {
              message: 'HSN Code is required.'
            },
          }
        },
        status: { // field name
          validators: {
            notEmpty: {
              message: 'Status is required.'
            },
          }
        },
         discription: {         
            stringLength: {
              max: 150,             
              message: 'Only 150 characters are allowed in Discription.'
            }
          }
       
      

      }
    }).on('success.form.bv', function(e) {
      e.preventDefault();
    });
  });
</script>
<script>
  var app = angular.module('myApp', []);
  app.controller('project', function($scope,$filter) {
    $scope.project = "Project";
    $scope.text = "Add";
    $scope.Add = 'plus';
     $scope.totalProjectstype = '0';
    $scope.fromProjectstype = '0';
    $scope.toProjectstype = '0';
    $scope.limit = '5';
    console.log($scope.limit);
    $scope.page = '0';
     //$scope.editdata='0';
$scope.list = <?php echo json_encode($list);?>;
console.log($scope.list);

    $scope.reset = function() {
      $('#project-type-form')[0].reset();
      $('#project-type-form').bootstrapValidator('resetForm', true);    
      $scope.editdata = [];
      $scope.text = "Add";
      $scope.Add = 'plus';
    }



$scope.preList = function(){
  $scope.page = parseInt($scope.page) - 1;
  window.setTimeout(function(){
    $scope.getallprojectType();
  },300);
}
$scope.nextList = function(){
  $scope.page = parseInt($scope.page) + 1;
  window.setTimeout(function(){
    $scope.getallprojectType();
  },300);
}

    $scope.editProjectType = function(id) {
      $.ajax({
        url: "<?php echo base_url() ?>projects/actions",
        type: "post",
        data: {
          action: "edit_project_type",
          id: id
        },
        dataType: "json",
        success: function(responce) {
          if (responce) {
            $scope.text = "Update";
            $scope.Add = "refresh";
            $scope.editdata= responce.res;
         //  $scope.editdata.due_date = $filter('date')(editdata.due_date, "dd/MM/yyyy");
           // console.log($scope.editdata.due_date);
          } else {
            alert(responce.public_msg);
          }
          $scope.$apply();
        }
      });
    }


    $scope.deleteProjectType = function(id) {
      if (confirm("Are you sure want to delete?")) {
        $.ajax({
          url: "<?php echo base_url() ?>projects/actions",
          type: "post",
          dataType: "json",
          data: {
            action: 'delete_project_type',
            id: id,
          },
          success: function(responce) {
            if (responce) {
              $scope.getallprojectType();
            } else {
              alert(responce.public_msg);
            }
            $scope.$apply();
          }
        });
      }
    }

    $scope.getallprojectType = function() {
      $.ajax({
        url: "<?php echo base_url() ?>projects/actions",
        type: "post",
        data: {
          action: 'get_project_type',page :$scope.page,limit:$scope.limit
        },
        dataType: "json",
        success: function(responce) {
          if (responce.succ) {
            $scope.allprojecttype = responce.res;
             $scope.totalProjectstype = responce.total_projectstype;
            
    $scope.fromProjectstype = parseInt($scope.limit) * parseInt($scope.page);
    $scope.toProjectstype = parseInt($scope.fromProjectstype) + parseInt($scope.allprojecttype.length);
          } else {

                  // $scope.allUsers = [];
                   $scope.totalProjectstype = '0';
                   $scope.fromProjectstype = '0';
                   $scope.toProjectstype = '0';
            alert(responce.public_msg);
            $scope.allprojecttype = [];
          }
          $scope.$apply();
        }
      })
    }
    $scope.save_or_update_project_type = function() {
    if (!$("#project-type-form").data('bootstrapValidator').validate().isValid()) {
        return false;
      }
      $.ajax({
        url: '<?php echo base_url() ?>projects/actions',
        'type': "post",
        data: $("#project-type-form").serialize(),
        dataType: 'json',
        success: function(response) {
          if (response.succ) {
            $scope.reset();
          } else {
            alert(response.public_msg);
          }
        }

      });
    }
    

    angular.element(document).ready(function() {
    $scope.getallprojectType();
   
    });
  })
</script>