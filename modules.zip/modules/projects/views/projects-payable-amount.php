<?php include('header.php')?>   
  <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.2/css/bootstrapValidator.min.css"/>
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.2/js/bootstrapValidator.min.js"></script>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link href="https://use.fontawesome.com/releases/v5.0.4/css/all.css" rel="stylesheet">

<body ng-app="myApp">
<div class="row" ng-controller="project">
 



  <div class="col-md-6">


    <div class="card card-contrast">
      <div class="card-header card-header-contrast header-success">
        <div class="caption">
          <button type="button" class="pull-left btn btn-danger"><i class="fa fa-{{Add}}"></i>&nbsp;{{text}} {{project}}</button>
        </div>
      </div>
      <div class="card-body">
        <form role="form" id="project-form" ng-submit="save_or_update_payable_amount()">
          <div class="form-body">
            <input type="hidden" name="id" value="{{editdata.id}}" />
            <input type="hidden" name="action" value="save_or_update_payable_amount">

     <div class="form-group">
              <label class="control-label">Select Project</label>
              <label class="control-label text-danger">(*)</label>
              <select class="form-control" name="project"  ng-model='editdata.project_id'>
                <option value="">--select--</option>
                <option ng-repeat="eachproject in projects" value="{{eachproject.id}}">{{eachproject.project_name}}</option>
              </select>
            </div>


            <div class="form-group">
              <label class="control-label">Enter Amount </label>
              <label class="control-label text-danger">(*)</label>
              <input type="text" placeholder="Enter Amount" class="form-control" name="amount" value="{{editdata.amount}}">
            </div>

            <div class="form-group">
              <label class="control-label">Enter Due Date </label>
              <label class="control-label text-danger">(*)</label>
              <input name="due_date" type="text" class="form-control" id="datepicker" value="{{editdata.due_date}}" placeholder="Enter Due Date.">
            </div>
 
         <!--  <div class="form-group">
              <label class="form-check-label">will repeapt </label>
             
              <input type="checkbox" class="form-check-input"  value="" >
            </div>
 -->





            <div class="form-check" >
         <label class="form-check-label">
       

         <input name="will_repeat" type="checkbox" class="form-check-input"  ng-checked="editdata.will_repeat==1  true:false">will repeat 
           </label>
           </div>

           
            <div class="form-group">
              <label class="control-label">Enter Remarks </label>
          
              <textarea name="remarks" class="form-control"  
              
               placeholder="Enter  Remarks"> {{editdata.payment_desc}}</textarea> 
          
            </div>

           

        
          
          </div>

          <div class="form-group">
            <div class="row">
              <div class="col-md-12">
                <button type="submit" class="btn btn-space btn-success"><i class="fa fa-{{Add}}"></i>&nbsp; {{text}} {{project}} </button>
                <button type="reset" ng-click="reset()" class="btn btn-space btn-danger"><i class="fa fa-times"> </i>&nbsp; Reset</button>
              </div>
            </div>
          </div>

        </form>
      </div>
    </div>
  </div>
  <div class="col-md-6">
     
    <div class="card card-contrast">

       <div class="card-header header-primary">

        <button style="float:right;" class="btn btn-success pull-right" ng-disabled="toProjects == totalProjects" type="button" ng-click="nextList()"><i class="fa fa-step-forward"></i>Next</button> 
        
      <button style="float:right;" class="btn btn-danger pull-right " ng-disabled="page == 0" type="button" ng-click="preList()"><i class="fa fa-step-backward"></i>Pre</button>
          

       <select style="float:right;"  class="form-control col-sm-3" name="list" ng-change='getallproject();'   ng-model='limit'  >
               
               <option ng-repeat="eachlist in list" value="{{eachlist.id}}">{{eachlist.list_name}}</option> 
              </select>
      <span style="float:right;">{{fromProjects + 1}} - {{toProjects}} of {{totalProjects}}</span>

      </div>
    
           
             
          
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered table-hover">
            <thead>
              <tr>
                <th>S. No</th>
                <th>Project</th>
                <th>Amount</th>
                <th>Due Date</th>
                <th>Will Repeat</th>
                <th>Remarks</th>
                <th>Action</th>
              </tr>
            </thead>

            <tbody>
              <tr ng-repeat="eachProject in allproject">
                <th>
                  {{ $index + 1+ fromProjects}}
                </th>
                <td>
                  <span  ng-if="eachProject.project_id == 1">NexGen Innovators</span>
                  <span  ng-if="eachProject.project_id  == 2">Project Tracker</span>
                  <span  ng-if="eachProject.project_id  == 3">Navtech</span>
                  
                </td>
                <td>

                  {{eachProject.amount}}
                </td>
                
                <td>
                  {{eachProject.due_date}}
                 
             
                </td>
                <td>
      
                    <span class="badge badge-success" ng-if="eachProject.will_repeat == 1">Yes</span>
                  <span class="badge badge-danger" ng-if="eachProject.will_repeat == 0">No</span> 
                </td>
                  <td>
                  {{eachProject.payment_desc}}
                </td>
              
                <td>
                  <button class="btn btn-success" ng-click="editProject(eachProject.id)"><i class="fa fa-edit"></i>Edit</button>
                  <button class="btn btn-danger" ng-click="deleteProject(eachProject.id)"><i class="fa fa-trash"></i> Delete</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
<script>
        $('#datepicker').datepicker({
            uiLibrary: 'bootstrap4'
        });
    </script>
<script>
  $(function() {
    $('#project-form').bootstrapValidator({
      message: false,
      trigger: null,
      live: 'enabled',
      fields: {
        project: { // field name
          validators: {
            notEmpty: {
              message: 'Project  is required.'
            },
           
          }
        },
        amount: { // field name
          validators: {
            notEmpty: {
              message: 'Amount  is required.'
            },
            stringLength: {
              max: 10,
              min: 1,
              message: 'Only 10 characters are Amount.'
            }
          }
        },
        due_date: { // field name
          validators: {
            notEmpty: {
              message: 'Due Date  is required.'
            },
          }
        },
        remarks: { // field name
          validators: {
            notEmpty: {
              message: 'Remarks  Sholud be Less Then 150 Charecter.'
            },
          }
        },
       

      }
    }).on('success.form.bv', function(e) {
      e.preventDefault();
    });
  });
</script>

<script>
  var app = angular.module('myApp', []);
  app.controller('project', function($scope,$filter) {
    $scope.project = "Project";
    $scope.text = "Add";
    $scope.Add = 'plus';
     $scope.totalProjects = '0';
    $scope.fromProjects = '0';
    $scope.toProjects = '0';
    $scope.limit = '5';
    console.log($scope.limit);
    $scope.page = '0';
     //$scope.editdata='0';

$scope.projects = <?php echo json_encode($projects);?>;
console.log($scope.projects);

$scope.list = <?php echo json_encode($list);?>;
console.log($scope.list);
    
    $scope.reset = function() {
      $('#project-form')[0].reset();
      $('#project-form').bootstrapValidator('resetForm', true);
      $scope.getallproject();
      $scope.editdata = [];
      $scope.text = "Add";
      $scope.Add = 'plus';
    }



$scope.preList = function(){
  $scope.page = parseInt($scope.page) - 1;
  window.setTimeout(function(){
    $scope.getallproject();
  },300);
}
$scope.nextList = function(){
  $scope.page = parseInt($scope.page) + 1;
  window.setTimeout(function(){
    $scope.getallproject();
  },300);
}

    $scope.editProject = function(id) {
      $.ajax({
        url: "<?php echo base_url() ?>projects/actions",
        type: "post",
        data: {
          action: "edit_payable_amount",
          id: id
        },
        dataType: "json",
        success: function(responce) {
          if (responce) {
            alert(responce.public_msg);
            $scope.text = "Update";
            $scope.Add = "refresh";
            $scope.editdata= responce.res;

         //  $scope.editdata.due_date = $filter('date')(editdata.due_date, "dd/MM/yyyy");
           // console.log($scope.editdata.due_date);
          } else {
            alert(responce.public_msg);
          }
          $scope.$apply();
        }
      });
    }


    $scope.deleteProject = function(id) {
      if (confirm("Are you sure want to delete?")) {
        $.ajax({
          url: "<?php echo base_url() ?>projects/actions",
          type: "post",
          dataType: "json",
          data: {
            action: 'delete_payable_amount',
            id: id,
          },
          success: function(responce) {
            if (responce) {
              $scope.getallproject();
              alert(responce.msg);
            } else {
              alert(responce.public_msg);
            }
            $scope.$apply();
          }
        });
      }
    }

    $scope.getallproject = function() {
      $.ajax({
        url: "<?php echo base_url() ?>projects/actions",
        type: "post",
        data: {
          action: 'get_payable_amount',page :$scope.page,limit:$scope.limit
        },
        dataType: "json",
        success: function(responce) {
          if (responce.succ) {
            $scope.allproject = responce.res;
             $scope.totalProjects = responce.total_projects;
            
    $scope.fromProjects = parseInt($scope.limit) * parseInt($scope.page);
    $scope.toProjects = parseInt($scope.fromProjects) + parseInt($scope.allproject.length);
          } else {

                  // $scope.allUsers = [];
                   $scope.totalProjects = '0';
                   $scope.fromProjects = '0';
                   $scope.toProjects = '0';
            alert(responce.public_msg);
            $scope.allproject = [];
          }
          $scope.$apply();
        }
      })
    }
    $scope.save_or_update_payable_amount = function() {
       if (!$("#project-form").data('bootstrapValidator').validate().isValid()) {
        return false;
       }
      $.ajax({
        url: '<?php echo base_url() ?>projects/actions',
        'type': "post",
        data: $("#project-form").serialize(),
        dataType: 'json',
        success: function(response) {
          if (response) {
            $scope.reset();
             alert(response.msg);
          } else {
            alert(response.public_msg);
          }
        }

      });
    }
    

       angular.element(document).ready(function() {
    $scope.getallproject();
   
    });
  })
</script>