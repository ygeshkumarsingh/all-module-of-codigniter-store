-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 05, 2020 at 10:55 AM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `store`
--

-- --------------------------------------------------------

--
-- Table structure for table `nexgi_projects_payable_amount`
--

DROP TABLE IF EXISTS `nexgi_projects_payable_amount`;
CREATE TABLE IF NOT EXISTS `nexgi_projects_payable_amount` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `amount` float DEFAULT NULL,
  `will_repeat` tinyint(1) NOT NULL DEFAULT '0',
  `due_date` date NOT NULL,
  `payment_desc` text,
  `received_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nexgi_projects_payable_amount`
--

INSERT INTO `nexgi_projects_payable_amount` (`id`, `project_id`, `amount`, `will_repeat`, `due_date`, `payment_desc`, `received_id`) VALUES
(1, 1, 1200, 1, '2020-03-27', ' Testing remarks', NULL),
(2, 1, 124, 1, '2020-04-02', '', NULL),
(3, 50, 124, 1, '2020-03-27', 'Remarks', NULL),
(4, 51, 13000, 1, '2020-03-27', 'Remarks', NULL),
(5, 53, 200000, 1, '2020-03-27', '', NULL),
(6, 43, 500, 1, '2020-03-30', '', NULL),
(28, 2, 344, 1, '2020-03-25', ' hghgh', NULL),
(29, 2, 344, 0, '2020-03-25', ' ljklklklk', NULL),
(30, 1, 0, 1, '2020-03-26', ' dfdfddsf', NULL),
(31, 2, 4343, 1, '2020-03-26', ' hjjghjghj', NULL),
(32, 2, 0, 1, '2020-03-26', ' fgfdgfdgfdgfdg', NULL),
(33, 1, 0, 1, '2020-03-26', ' gfgfg', NULL),
(34, 1, 4343, 1, '2020-03-26', ' hggfhgh', NULL),
(35, 2, 434343000, 1, '2020-03-26', ' fgfgfgfd', NULL),
(36, 2, 123457000, 1, '2020-03-26', ' jhjhjhg', NULL),
(37, 1, 123, 0, '2020-04-04', '  hgthgfhgh', NULL),
(41, 1, 3432430, 1, '2020-04-05', '  789456', NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
