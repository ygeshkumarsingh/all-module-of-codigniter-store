<?php
class M_projects extends CI_Model
{
	

	public function save_or_update_payable_amount($formData)
	{
		//print_r($formData);
		//die();
		$date=$formData['due_date'];
		$date=date("Y-m-d");
		$insert_array = array(
			"project_id " => $formData['project'],
			"amount" => $formData['amount'],
			"will_repeat" => $formData['will_repeat'],
			"due_date" => $date,
		    "payment_desc" => $formData['remarks'],
		
		);

		if (isset($formData['id']) && !empty($formData['id'])) {

			return $this->db->update("nexgi_projects_payable_amount", $insert_array, array("id" => $formData['id']));
		} else {
			return $this->db->insert("nexgi_projects_payable_amount", $insert_array);
		}
	}

    public function save_or_update_project_type($formData)
	{
		//print_r($formData);
		//die();
		
		$insert_array = array(
			"name " => $formData['name'],
			"code" => $formData['code'],
			"status " => $formData['status'],
			"hsn_code" => $formData['hsn_code'],
			"discription" => $formData['discription'],
			
		
		);

		if (isset($formData['id']) && !empty($formData['id'])) {

			return $this->db->update("nexgi_projects_type", $insert_array, array("id" => $formData['id']));
		} else {
			return $this->db->insert("nexgi_projects_type", $insert_array);
		}
	}
	public function get_payable_amount($filters = array())
	{
		$this->db->select('s.*');
		$this->db->from('nexgi_projects_payable_amount s');
	
		if (isset($filters['id']) && !empty($filters['id'])) {
			$this->db->where("s.id", $filters['id']);
			return $this->db->get()->row_array();
		}
		$this->db->order_by('id', "DESC");
		$this->db->group_by('id');
		//$date=date("d-m-d");
	if(isset($filters['count'])){
		return $this->db->count_all_results();
	}
		if (isset($filters['limit']) && $filters['limit'] != 0) {
            $limit = $filters['limit'];
            $offset = (isset($filters['page']) && !empty($filters['page'])) ? $limit * $filters['page'] : 0;
            $this->db->limit($limit, $offset);
        }


		return $this->db->get()->result_array();
	}

public function get_project_type($filters = array())
	{
		$this->db->select('s.*');
		$this->db->from('nexgi_projects_type s');
	
		if (isset($filters['id']) && !empty($filters['id'])) {
			$this->db->where("s.id", $filters['id']);
			return $this->db->get()->row_array();
		}
		$this->db->order_by('id', "DESC");
		$this->db->group_by('id');
		//$date=date("d-m-d");
	if(isset($filters['count'])){
		return $this->db->count_all_results();
	}
		if (isset($filters['limit']) && $filters['limit'] != 0) {
            $limit = $filters['limit'];
            $offset = (isset($filters['page']) && !empty($filters['page'])) ? $limit * $filters['page'] : 0;
            $this->db->limit($limit, $offset);
        }


		return $this->db->get()->result_array();
	}
	public function delete_payable_amount($formData)
	{
		$this->db->where('id', $formData['id']);
		return $this->db->delete('nexgi_projects_payable_amount');
	}
	public function delete_project_type($formData)
	{
		$this->db->where('id', $formData['id']);
		return $this->db->delete('nexgi_projects_type');
	}

public function checkProjectTypeExists($filters = array())
{
		$this->db->select("id")->from("nexgi_projects_type");
/*if(isset($filters['mobile']) && !empty($filters['mobile'])){
	$this->db->where("(mobile1 =  '{$filters['mobile']}' or mobile2 = '{$filters['mobile']}')",NULL,FALSE);
}*/

if(isset($filters['not_id']) && !empty($filters['not_id'])){
	$this->db->where("id !=",$filters['not_id']);
}

if(isset($filters['name']) && !empty($filters['name'])){
	$this->db->where("name",$filters['name']);
}

if(isset($filters['code']) && !empty($filters['code'])){
	$this->db->where("code",$filters['code']);
}
		return $this->db->count_all_results();
	}


}
