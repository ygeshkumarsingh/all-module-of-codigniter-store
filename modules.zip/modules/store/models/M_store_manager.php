<?php
class M_store_manager extends CI_Model
{
	public function allstate()
	{
		$this->db->select('*');
		$this->db->from('arc_terms');
		$this->db->where('term_type', "states");
		return $this->db->get()->result_array();
	}

	public function allcity($formData)
	{
		$this->db->select('*');
		$this->db->from('arc_terms');
		$this->db->where('term_type', "city");
		$this->db->where('parent_id', $formData['id']);
		return $this->db->get()->result_array();
	}

	public function add_or_update_store($formData)
	{
		$insert_array = array(
			"store_name" => $formData['store_name'],
			"contact" => $formData['contact'],
			"latitude" => $formData['latitude'],
			"longitude" => $formData['longitude'],
			"state" => $formData['state'],
			"city" => $formData['city'],
			"status" => $formData['status']
		);

		if (isset($formData['id']) && !empty($formData['id'])) {
			return $this->db->update("store", $insert_array, array("id" => $formData['id']));
		} else {
			return $this->db->insert("store", $insert_array);
		}
	}

	public function get_all_store($filters = array())
	{
		$this->db->select('s.*, at.name as state_name , ae.name as city_name');
		$this->db->from('store s');
		$this->db->join('arc_terms at', 'at.id = s.state', "left");
		$this->db->join('arc_terms ae', 'ae.id = s.city', "left");
		if (isset($filters['id']) && !empty($filters['id'])) {
			$this->db->where("s.id", $filters['id']);
			return $this->db->get()->row_array();
		}
		$this->db->order_by('id', "DESC");
		$this->db->group_by('id');
		
		return $this->db->get()->result_array();
	}

	public function delete_store($formData)
	{
		$this->db->where('id', $formData['id']);
		return $this->db->delete('store');
	}
}
