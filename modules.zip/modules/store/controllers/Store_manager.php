<?php
class Store_manager extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('m_store_manager', 'ms');
	}

	public function index()
	{
		$this->adminTemplate('store_manager_index');
	}

	public function allstate()
	{
		$getdata = $this->ms->allstate();
		$this->public_msg = "Fetch  all state successfully.";
		$this->response(array("res" => $getdata));
	}

	public function allcity()
	{
		$formData = $this->input->post();
		$getdata = $this->ms->allcity($formData);
		$this->public_msg = "Fetch  all city successfully.";
		$this->response(array("res" => $getdata));
	}

	public function actions()
	{
		try {
			$formData = $this->input->post();
			if (!isset($formData['action']) || (isset($formData['action']) && $formData['action'] == '')) {
				throw new Exception("Action not define");
			}
			$action = $formData['action'];
			if ($action == 'add_or_update_store') {
				$this->_save_store($formData);
			} elseif ($action == 'getallstore') {
				$this->_get_all_store($formData);
			} elseif ($action == 'deleteStore') {
				$this->_delete_store($formData);
			} elseif ($action == 'editStore') {
				$this->_edit_store($formData);
			} else {
				throw new Exception("Invalid Action.");
			}
		} catch (Exception $ex) {
			$this->_err[''] = $ex->getMessage();
			$this->response();
		}
	}

	public function _edit_store($formData)
	{
		if (!$formData['id']) {
			throw new Exception("Cap Id is required.");
		}
		$edit_store = $this->ms->get_all_store(array("id" => $formData['id']));
		$this->public_msg = "Single cap fetch successfully .";
		$this->response(array("editStore" => $edit_store));
	}

	public function _delete_store($formData)
	{
		if (!$formData['id']) {
			throw new Exception("Store id is required");
		}
		$deletstore = $this->ms->delete_store(array("id" => $formData['id']));
		$this->public_msg = "Caps Deleted successfully .";
		$this->response($deletstore);
	}

	public function _get_all_store($formData)
	{
		$getdata = $this->ms->get_all_store($formData);
		$this->public_msg = "Fetch  all Store successfully.";
		$this->response(array("res" => $getdata));
	}

	public function _save_store($formData)
	{
		$this->_validate_store($formData);
		if (!$this->ms->add_or_update_store($formData)) {
			throw new Exception("Error while processing.");
		}
		if (isset($formData['id']) && !empty($formData['id'])) {
			$this->public_msg = "Update successfully.";
		} else {
			$this->public_msg = "Save successfully.";
		}
		$this->response();
	}

	public function _validate_store($formData)
	{
		if (!isset($formData['store_name']) || (isset($formData['store_name']) && $formData['store_name']) == '') {
			throw new Exception(" Store name is required");
		} elseif (preg_match("/^[a-zA-Z- ]*$/", $formData['store_name']) != 1) {
			throw new Exception("A-z,space and - are allowed in store name.");
		}
		if (!isset($formData['contact']) || (isset($formData['contact']) && $formData['contact']) == '') {
			throw new Exception("Contact name is required");
		} else if (strlen($formData['contact']) != 10) {
			throw new Exception("Contact number must be 10 digits.");
		}
		if (!isset($formData['latitude']) || (isset($formData['latitude']) && $formData['latitude']) == '') {
			throw new Exception("Latitude is required");
		}
		if (!isset($formData['longitude']) || (isset($formData['longitude']) && $formData['longitude']) == '') {
			throw new Exception("Longitude is required");
		}
		if (!isset($formData['state']) || (isset($formData['state']) && $formData['state']) == '') {
			throw new Exception("State is required");
		}
		if (!isset($formData['city']) || (isset($formData['city']) && $formData['city']) == '') {
			throw new Exception("City is required");
		}
		if (!isset($formData['status']) || (isset($formData['status']) && $formData['status'] == "")) {
			throw new Exception("Status is required.");
		}
	}
}
