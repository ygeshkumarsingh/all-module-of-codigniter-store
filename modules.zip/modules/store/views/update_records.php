<!DOCTYPE html>
<html>
<head>
<title>Registration form</title>
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
</head>

<body ng-app="myApp">
  <?php
  $i=1;
  foreach($data as $row)
  {
  ?>
   <div  ng-controller="myCtrl">
  <form method="post">
    <table width="400" border="1" cellspacing="" cellpadding="5">
  <tr>
    <td width="230">Enter Store Name </td>
    <td ><input type="text" name="store_name" value="<?php echo $row->StoreName; ?>"/></td>
  </tr>
  <tr>
    <td>Enter Contact Number </td>
    <td><input type="text" name="contact" value="<?php echo $row->Contact; ?>"/></td>

  </tr>

   <tr>
    <td>Enter Location </td>
    <td><input type="text" name="location" value="<?php echo $row->$latitude."".$row->$longitude; ?>"/></td>
  </tr>
   <tr>
    <td>Enter State </td>
    <td>
   <select class="form-control" name="state" ng-model="state_id" ng-change="loadList('city')">
 <option value="">--select--</option>
  <option ng-repeat="eachProject in state" value="{{eachProject.id}}">{{eachProject.name}}</option>
   </select>

    </td>
  </tr>
   <tr>
    <td>Enter City </td>
    <td>
<select class="form-control" name="city">
   <option value="">--select--</option>
  <option ng-repeat="eachcity in city" value="{{eachcity.id}}">{{eachcity.name}}</option>
   </select>
    </td>
  </tr>
  <tr>
    <td>Enter Status </td>
    <td>

              <select class="form-control" name="status" id="status" >
                <option value="1" selected="true">Active</option>
                <option value="0">Inactive</option>
              </select>
         


    </td>
  </tr>
  <tr>
    <td colspan="2" align="center">
      <input type="submit" name="update" value="Upadate Record"/></td>
  </tr>
  
</table>

  </form>
</div>
   <?php } ?>
</body>
</html>



<script>
  var app = angular.module('myApp', []);
 app.controller('myCtrl', function($scope) {
  $scope.state_list  = [];
  $scope.city_list = [];


        $scope.state = <?php echo json_encode($state) ?>;
       $scope.city = <?php echo json_encode($city) ?>;

       $scope.loadList = function(term_type){
      var parent_id = 0;
         if(term_type == 'city'){
          $scope.city_list = [];
          // process for city data
          parent_id = $scope.state_id; 
         }

         if(term_type == 'state'){
          // process for state data 
         }

if(parent_id){

$.ajax({
    url: '<?=base_url()?>store_manager/term_type',
    type: 'POST',
    dataType:'json',
    data: {parent_id: parent_id,term_type:term_type},
    success:function(response){
       $scope.city = response.city;
       // console.log( $scope.city);

      $scope.$apply();
    }
  })
  
  
}
       }
     });




</script>

