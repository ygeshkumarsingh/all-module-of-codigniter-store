<!DOCTYPE html>
<html>
<head>
<title>Display Records</title>
</head>

<body>
<table width="600" border="1" cellspacing="5" cellpadding="5">
  <tr style="background:#CCC">
    <th>Sr No</th>
    <th>Store Name</th>
    <th>Contact</th>
    <th>Location</th>
    <th>State</th>
    <th>City</th>
     <th>Status</th>
       <th>Delete</th>
          <th>Update</th>
  </tr>
  <?php
  $i=1;
  foreach($data as $row)
  {
  echo "<tr>";
  echo "<td>".$i."</td>";
  echo "<td>".$row->StoreName."</td>";
  echo "<td>".$row->Contact."</td>";
  echo "<td>".$row->latitude.",".$row->longitude."</td>";
   echo "<td>".$row->state."</td>";
  echo "<td>".$row->city."</td>";
   echo "<td>".$row->status."</td>";
   echo "<td><a href='deletedata?id=".$row->id."'>Delete</a></td>";
   echo "<td><a href='updatedata?id=".$row->id."'>Update</a></td>";
  echo "</tr>";
  $i++;
  }
   ?>
</table>

</body>
</html>-