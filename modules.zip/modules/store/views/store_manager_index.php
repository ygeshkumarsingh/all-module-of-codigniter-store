<div class="row" ng-controller="store">
  <div class="col-md-6">
    <div class="card card-contrast">
      <div class="card-header card-header-contrast header-success">
        <div class="caption">
          <button type="button" class="pull-left btn btn-danger"><i class="fa fa-{{Add}}"></i>&nbsp;{{text}} {{store}}</button>
        </div>
      </div>
      <div class="card-body">
        <form role="form" id="store-form" ng-submit="add_or_update_store()">
          <div class="form-body">
            <input type="hidden" name="id" value="{{editdata.id}}" />
            <input type="hidden" name="action" value="add_or_update_store">

            <div class="form-group">
              <label class="control-label">Enter Store Name</label>
              <label class="control-label text-danger">(*)</label>
              <input type="text" placeholder="Enter store name" class="form-control" name="store_name" value="{{editdata.store_name}}">
            </div>

            <div class="form-group">
              <label class="control-label">Enter Contact Number </label>
              <label class="control-label text-danger">(*)</label>
              <input type="text" class="form-control" name="contact" value="{{editdata.contact}}" placeholder="Enter contact number.">
            </div>

            <div class="form-group">
              <label class="control-label">Enter Latitude Location</label>
              <label class="control-label text-danger">(*)</label>
              <input type="text" class="form-control" name="latitude" value="{{editdata.latitude}}" placeholder="Enter latitude address">
            </div>
            <div class="form-group">
              <label class="control-label">Enter Longitude Location</label>
              <label class="control-label text-danger">(*)</label>
              <input type="text" class="form-control" name="longitude" value="{{editdata.longitude}}" placeholder="Enter longitude address">
            </div>

            <div class="form-group">
              <label class="control-label">Select State</label>
              <label class="control-label text-danger">(*)</label>
              <select class="form-control" name="state" ng-change='getallcity()' ng-model='editdata.state'>
                <option value="">--select--</option>
                <option ng-repeat="eachstate in allState" value="{{eachstate.id}}">{{eachstate.name}}</option>
              </select>
            </div>

            <div class="form-group">
              <label class="control-label">Select City</label>
              <label class="control-label text-danger">(*)</label>
              <select name='city' class="form-control" ng-model='editdata.city'>
                <option value="">select</option>
                <option ng-repeat='eachCity in allCity' value="{{eachCity.id}}">{{eachCity.name}}</option>
              </select>
            </div>

            <div class="form-group">
              <label class="control-label">Status</label>
              <label class="control-label text-danger">(*)</label>
              <select class="form-control" name="status" ng-model="editdata.status">
                <option value="">--select--</option>
                <option value="1">Enable</option>
                <option value="0">Disable</option>
              </select>
            </div>

          </div>

          <div class="form-group">
            <div class="row">
              <div class="col-md-12">
                <button type="submit" class="btn btn-space btn-success"><i class="fa fa-{{Add}}"></i>&nbsp; {{text}} {{store}} </button>
                <button type="reset" ng-click="reset()" class="btn btn-space btn-danger"><i class="fa fa-times"> </i>&nbsp; Reset</button>
              </div>
            </div>
          </div>

        </form>
      </div>
    </div>
  </div>
  <div class="col-md-6">
    <div class="card card-contrast">
      <div class="card-header header-primary">
        <div class="caption">
          <button class="pull-right btn margin-r10x btn-info" ng-click="getCap()"><span class="fa fa-refresh"></span> <span class="hidden-sm">Refresh</span></button>
        </div>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered table-hover">
            <thead>
              <tr>
                <th>S. No</th>
                <th>Store Name</th>
                <th>Contact N.</th>
                <th>State</th>
                <th>City</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>

            <tbody>
              <tr ng-repeat="eachStore in allStore">
                <th>
                  {{ $index + 1}}
                </th>
                <td>
                  {{eachStore.store_name}}
                </td>
                <td>
                  {{eachStore.contact}}
                </td>
                <td>
                  {{eachStore.state_name}}
                </td>
                <td>
                  {{eachStore.city_name}}
                </td>
                <td>
                  <span class="badge badge-success" ng-if="eachStore.status == 1">Enable</span>
                  <span class="badge badge-danger" ng-if="eachStore.status == 0">Disable</span>
                </td>
                <td>
                  <button class="btn btn-success" ng-click="editStore(eachStore.id)"><i class="fa fa-edit"></i>Edit</button>
                  <button class="btn btn-danger" ng-click="deleteStore(eachStore.id)"><i class="fa fa-trash"></i> Delete</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  $(function() {
    $('#store-form').bootstrapValidator({
      message: false,
      trigger: null,
      live: 'enabled',
      fields: {
        store_name: { // field name
          validators: {
            notEmpty: {
              message: 'Store name is required.'
            },
            regexp: {
              regexp: /^[a-zA-Z -]+$/,
              message: 'A-z,space and - are allowed in store name.'
            },
          }
        },
        contact: { // field name
          validators: {
            notEmpty: {
              message: 'Contact number is required.'
            },
            stringLength: {
              max: 10,
              min: 10,
              message: 'Only 10 characters are contact number.'
            }
          }
        },
        latitude: { // field name
          validators: {
            notEmpty: {
              message: 'Latitude address is required.'
            },
          }
        },
        longitude: { // field name
          validators: {
            notEmpty: {
              message: 'Longitude address is required.'
            },
          }
        },
        status: { // field name
          validators: {
            notEmpty: {
              message: 'status is required.'
            },
          }
        },
        city: { // field name
          validators: {
            notEmpty: {
              message: 'City is required.'
            },
          }
        },
        state: { // field name
          validators: {
            notEmpty: {
              message: 'State is required.'
            },
          }
        },

      }
    }).on('success.form.bv', function(e) {
      e.preventDefault();
    });
  });
</script>
<script>
  app.controller('store', function($scope) {
    $scope.store = "Stores";
    $scope.text = "Add";
    $scope.Add = 'plus';

    $scope.reset = function() {
      $('#store-form')[0].reset();
      $('#store-form').bootstrapValidator('resetForm', true);
      $scope.getallstate();
      $scope.getallstore();
      $scope.editdata = [];
      $scope.text = "Add";
      $scope.Add = 'plus';
    }

    $scope.editStore = function(id) {
      $.ajax({
        url: "<?php echo base_url() ?>store_manager/actions",
        type: "post",
        data: {
          action: "editStore",
          id: id
        },
        dataType: "json",
        success: function(responce) {
          if (responce.data) {
            $scope.text = "Update";
            $scope.Add = "refresh";
            $scope.-+ = responce.data.editStore;
            $scope.getallcity();
          } else {
            alert(responce.public_msg);
          }
          $scope.$apply();
        }
      });
    }


    $scope.deleteStore = function(id) {
      if (confirm("Are you sure want to delete?")) {
        $.ajax({
          url: "<?php echo base_url() ?>store_manager/actions",
          type: "post",
          dataType: "json",
          data: {
            action: 'deleteStore',
            id: id,
          },
          success: function(responce) {
            if (responce.succ) {
              $scope.reset();
            } else {
              alert(responce.public_msg);
            }
            $scope.$apply();
          }
        });
      }
    }

    $scope.getallstore = function() {
      $.ajax({
        url: "<?php echo base_url() ?>store_manager/actions",
        type: "post",
        data: {
          action: 'getallstore',
        },
        dataType: "json",
        success: function(responce) {
          if (responce.data) {
            $scope.allStore = responce.data.res;
            // console.log($scope.allStore);
          } else {
            alert(responce.public_msg);
            $scope.allStore = [];
          }
          $scope.$apply();
        }
      })
    }
    $scope.add_or_update_store = function() {
      if (!$("#store-form").data('bootstrapValidator').validate().isValid()) {
        return false;
      }
      $.ajax({
        url: '<?php echo base_url() ?>store_manager/actions',
        'type': "post",
        data: $("#store-form").serialize(),
        dataType: 'json',
        success: function(response) {
          if (response.succ) {
            $scope.reset();
          } else {
            alert(response.public_msg);
          }
        }

      });
    }
    $scope.getallstate = function() {
      $.ajax({
        url: "<?php echo base_url(); ?>store_manager/allstate",
        type: "post",
        dataType: "json",
        success: function(response) {
          if (response.succ) {
            $scope.allState = response.data.res;
            // console.log($scope.allState);
          }
          $scope.$apply();
        }
      });
    }
    $scope.getallcity = function() {
      $.ajax({
        url: "<?php echo base_url(); ?>store_manager/allcity",
        type: "post",
        dataType: "json",
        data: {
          id: $scope.editdata['state']
        },
        success: function(response) {
          if (response.succ) {
            $scope.allCity = response.data.res;
            // console.log($scope.allCity);
          }
          $scope.$apply();
        }
      });
    }

    angular.element(document).ready(function() {
      $scope.getallstore();
      $scope.getallstate();
    });
  })
</script>